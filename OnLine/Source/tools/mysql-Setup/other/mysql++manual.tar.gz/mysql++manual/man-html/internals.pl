# LaTeX2HTML 99.2beta8 (1.43)
# Associate internals original text with physical files.


$key = q/Overview/;
$ref_files{$key} = "$dir".q|2_Overview.html|; 
$noresave{$key} = "$nosave";

$key = q/SQLQueryParms/;
$ref_files{$key} = "$dir".q|5_Class.html|; 
$noresave{$key} = "$nosave";

$key = q/manip/;
$ref_files{$key} = "$dir".q|5_Class.html|; 
$noresave{$key} = "$nosave";

$key = q/SQLQuery/;
$ref_files{$key} = "$dir".q|5_Class.html|; 
$noresave{$key} = "$nosave";

$key = q/template_format/;
$ref_files{$key} = "$dir".q|6_Template.html|; 
$noresave{$key} = "$nosave";

$key = q/SSQLS/;
$ref_files{$key} = "$dir".q|7_Specialized.html|; 
$noresave{$key} = "$nosave";

1;

